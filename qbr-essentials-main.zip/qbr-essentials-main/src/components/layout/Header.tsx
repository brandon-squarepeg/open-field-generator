
import React from 'react';

interface HeaderProps {
  companyName: string;
  companyLogo?: string;
}

const Header: React.FC<HeaderProps> = ({ companyName, companyLogo }) => {
  return (
    <header className="p-4 border-b border-gray-800 bg-qbr-bg-card flex items-center justify-between">
      <div className="flex items-center gap-4">
        <div className="h-12 w-12 rounded-lg bg-white/10 flex items-center justify-center">
          {companyLogo ? (
            <img src={companyLogo} alt={`${companyName} logo`} className="h-8 w-8 object-contain" />
          ) : (
            <span className="text-xl font-bold">{companyName.charAt(0)}</span>
          )}
        </div>
        <div>
          <h1 className="text-xl font-bold">{companyName}</h1>
          <p className="text-sm text-qbr-text-secondary">Quarterly Business Review</p>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <div className="dashboard-card p-2">
          <span className="stat-label">Quarter</span>
          <div className="stat-value">Q2 2023</div>
        </div>
        <div className="dashboard-card p-2">
          <span className="stat-label">Last Update</span>
          <div className="stat-value">June 15, 2023</div>
        </div>
      </div>
    </header>
  );
};

export default Header;
