
import React from 'react';
import { 
  LayoutDashboard, 
  Users, 
  Target, 
  BarChart3, 
  FileClock, 
  Calendar, 
  MessageSquare, 
  PanelRight,
  BellRing
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface SidebarProps {
  className?: string;
}

const Sidebar: React.FC<SidebarProps> = ({ className }) => {
  // Array of menu items with their respective icons
  const menuItems = [
    { icon: LayoutDashboard, label: 'Overview', href: '#overview' },
    { icon: Calendar, label: 'Partnership Timeline', href: '#partnership-timeline' },
    { icon: Users, label: 'Contact Info', href: '#contact-info' },
    { icon: Target, label: 'Partnership Goals', href: '#partnership-goals' },
    { icon: BarChart3, label: 'Adoption Stats', href: '#adoption-stats' },
    { icon: FileClock, label: 'ROI Stats', href: '#roi-stats' },
    { icon: PanelRight, label: 'Feature Requests', href: '#feature-requests' },
    { icon: Calendar, label: 'SquarePeg Roadmap', href: '#squarepeg-roadmap' },
    { icon: BellRing, label: 'Announcements', href: '#announcements' },
  ];

  return (
    <aside className={cn('w-64 bg-qbr-bg-card border-r border-gray-800 min-h-screen p-4 flex flex-col', className)}>
      <div className="mb-8">
        <h2 className="text-xl font-bold mb-1 text-qbr-accent-teal">SquarePeg</h2>
        <p className="text-sm text-qbr-text-secondary">QBR Dashboard</p>
      </div>
      
      <nav className="flex-1">
        <ul className="space-y-1">
          {menuItems.map((item, index) => (
            <li key={index}>
              <a 
                href={item.href}
                className="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-gray-800/50 text-qbr-text-secondary hover:text-white transition-colors"
              >
                <item.icon size={18} className="text-qbr-accent-teal" />
                <span>{item.label}</span>
              </a>
            </li>
          ))}
        </ul>
      </nav>
      
      <div className="mt-auto pt-4 border-t border-gray-800">
        <div className="flex items-center gap-3 px-3 py-2">
          <div className="w-8 h-8 rounded-full bg-qbr-accent-purple/30 flex items-center justify-center">
            <span className="text-sm font-medium">CS</span>
          </div>
          <div>
            <p className="text-sm font-medium">Client Success</p>
            <p className="text-xs text-qbr-text-secondary">Q2 2023</p>
          </div>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
