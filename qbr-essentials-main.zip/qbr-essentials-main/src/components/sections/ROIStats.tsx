
import React from 'react';
import { Clock, DollarSign, Timer, Award, TrendingDown, TrendingUp } from 'lucide-react';

interface ROIStatsProps {
  stats: {
    hoursSaved: number;
    hoursSavedLastPeriod: number;
    moneySaved: number;
    moneySavedLastPeriod: number;
    timeToFill: string;
    timeToFillLastPeriod: string;
    qualityScore: number;
    qualityScoreLastPeriod: number;
  };
}

const ROIStats: React.FC<ROIStatsProps> = ({ stats }) => {
  // Calculate percentage changes
  const hoursSavedChange = ((stats.hoursSaved - stats.hoursSavedLastPeriod) / stats.hoursSavedLastPeriod) * 100;
  const moneySavedChange = ((stats.moneySaved - stats.moneySavedLastPeriod) / stats.moneySavedLastPeriod) * 100;
  const qualityScoreChange = stats.qualityScore - stats.qualityScoreLastPeriod;
  
  // Convert timeToFill to numbers for comparison (assuming format like "18 days")
  const currentDays = parseInt(stats.timeToFill.split(' ')[0]);
  const lastPeriodDays = parseInt(stats.timeToFillLastPeriod.split(' ')[0]);
  const timeToFillChange = ((lastPeriodDays - currentDays) / lastPeriodDays) * 100;

  return (
    <section id="roi-stats" className="p-6">
      <h2 className="section-title">ROI Statistics</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <div className="dashboard-card">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-full bg-qbr-accent-purple/20 flex items-center justify-center">
              <Clock size={20} className="text-qbr-accent-purple" />
            </div>
            <p className="text-qbr-text-secondary">Hours Saved</p>
          </div>
          <div className="flex items-center justify-between">
            <p className="text-3xl font-bold text-left pl-14">{stats.hoursSaved}</p>
            <div className="flex items-center gap-1 text-sm">
              {hoursSavedChange > 0 ? (
                <>
                  <TrendingUp size={16} className="text-green-500" />
                  <span className="text-green-500">+{hoursSavedChange.toFixed(1)}%</span>
                </>
              ) : (
                <>
                  <TrendingDown size={16} className="text-red-500" />
                  <span className="text-red-500">{hoursSavedChange.toFixed(1)}%</span>
                </>
              )}
            </div>
          </div>
        </div>
        
        <div className="dashboard-card">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-full bg-qbr-accent-teal/20 flex items-center justify-center">
              <DollarSign size={20} className="text-qbr-accent-teal" />
            </div>
            <p className="text-qbr-text-secondary">Money Saved</p>
          </div>
          <div className="flex items-center justify-between">
            <p className="text-3xl font-bold text-left pl-14">${stats.moneySaved.toLocaleString()}</p>
            <div className="flex items-center gap-1 text-sm">
              {moneySavedChange > 0 ? (
                <>
                  <TrendingUp size={16} className="text-green-500" />
                  <span className="text-green-500">+{moneySavedChange.toFixed(1)}%</span>
                </>
              ) : (
                <>
                  <TrendingDown size={16} className="text-red-500" />
                  <span className="text-red-500">{moneySavedChange.toFixed(1)}%</span>
                </>
              )}
            </div>
          </div>
        </div>
        
        <div className="dashboard-card">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-full bg-qbr-accent-blue/20 flex items-center justify-center">
              <Timer size={20} className="text-qbr-accent-blue" />
            </div>
            <p className="text-qbr-text-secondary">Time to Fill</p>
          </div>
          <div className="flex items-center justify-between">
            <p className="text-3xl font-bold text-left pl-14">{stats.timeToFill}</p>
            <div className="flex items-center gap-1 text-sm">
              {timeToFillChange > 0 ? (
                <>
                  <TrendingUp size={16} className="text-green-500" />
                  <span className="text-green-500">+{timeToFillChange.toFixed(1)}%</span>
                </>
              ) : (
                <>
                  <TrendingDown size={16} className="text-red-500" />
                  <span className="text-red-500">{timeToFillChange.toFixed(1)}%</span>
                </>
              )}
            </div>
          </div>
        </div>
        
        <div className="dashboard-card">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-full bg-qbr-accent-purple/20 flex items-center justify-center">
              <Award size={20} className="text-qbr-accent-purple" />
            </div>
            <p className="text-qbr-text-secondary">Quality Score</p>
          </div>
          <div className="flex items-center justify-between">
            <p className="text-3xl font-bold text-left pl-14">{stats.qualityScore}%</p>
            <div className="flex items-center gap-1 text-sm">
              {qualityScoreChange > 0 ? (
                <>
                  <TrendingUp size={16} className="text-green-500" />
                  <span className="text-green-500">+{qualityScoreChange}%</span>
                </>
              ) : (
                <>
                  <TrendingDown size={16} className="text-red-500" />
                  <span className="text-red-500">{qualityScoreChange}%</span>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ROIStats;
