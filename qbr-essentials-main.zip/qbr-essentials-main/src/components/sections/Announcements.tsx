
import React from 'react';
import { Bell, Calendar } from 'lucide-react';

interface Announcement {
  id: number;
  title: string;
  date: string;
  description: string;
  isNew?: boolean;
}

interface AnnouncementsProps {
  announcements: Announcement[];
}

const Announcements: React.FC<AnnouncementsProps> = ({ announcements }) => {
  return (
    <section id="announcements" className="p-6">
      <h2 className="section-title">Key Announcements</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {announcements.map((announcement) => (
          <div key={announcement.id} className="dashboard-card">
            <div className="flex justify-between items-start mb-3">
              <h3 className="font-medium flex items-center gap-2">
                <Bell size={16} className="text-qbr-accent-teal" />
                {announcement.title}
                {announcement.isNew && (
                  <span className="text-xs px-2 py-0.5 bg-qbr-accent-purple/20 text-qbr-accent-purple rounded-full">
                    New
                  </span>
                )}
              </h3>
              <div className="flex items-center text-sm text-qbr-text-secondary">
                <Calendar size={14} className="mr-1" />
                {announcement.date}
              </div>
            </div>
            
            <p className="text-qbr-text-secondary">{announcement.description}</p>
          </div>
        ))}
      </div>
    </section>
  );
};

export default Announcements;
