
import React from 'react';
import { Users, UserCheck, FileText, Eye, Clock, Activity } from 'lucide-react';
import { ChartContainer } from '../ui/chart';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend 
} from 'recharts';

interface AdoptionStatsProps {
  stats: {
    applicantsIngested: number;
    candidatesScored: number;
    jobRequirementsSaved: number;
    candidatesViewed: number;
    candidatesActioned: number;
    usersActive: number;
    avgTimeInStage: string;
    monthlyData: Array<{
      month: string;
      applicantsIngested: number;
      candidatesScored: number;
      candidatesViewed: number;
      candidatesActioned: number;
    }>;
  };
}

const AdoptionStats: React.FC<AdoptionStatsProps> = ({ stats }) => {
  return (
    <section id="adoption-stats" className="p-6">
      <h2 className="section-title">Adoption Statistics</h2>
      
      <div className="dashboard-card mb-6">
        <h3 className="subsection-title mb-4">Key Metrics</h3>
        
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          <div className="p-3 bg-gray-800/30 rounded-lg flex flex-col items-center">
            <Users size={24} className="text-qbr-accent-teal mb-2" />
            <p className="text-sm text-qbr-text-secondary">Applicants Ingested</p>
            <p className="text-xl font-bold">{stats.applicantsIngested}</p>
          </div>
          
          <div className="p-3 bg-gray-800/30 rounded-lg flex flex-col items-center">
            <UserCheck size={24} className="text-qbr-accent-teal mb-2" />
            <p className="text-sm text-qbr-text-secondary">Candidates Scored</p>
            <p className="text-xl font-bold">{stats.candidatesScored}</p>
          </div>
          
          <div className="p-3 bg-gray-800/30 rounded-lg flex flex-col items-center">
            <FileText size={24} className="text-qbr-accent-teal mb-2" />
            <p className="text-sm text-qbr-text-secondary">Job Requirements Saved</p>
            <p className="text-xl font-bold">{stats.jobRequirementsSaved}</p>
          </div>
          
          <div className="p-3 bg-gray-800/30 rounded-lg flex flex-col items-center">
            <Eye size={24} className="text-qbr-accent-teal mb-2" />
            <p className="text-sm text-qbr-text-secondary">Candidates Viewed</p>
            <p className="text-xl font-bold">{stats.candidatesViewed}</p>
          </div>
          
          <div className="p-3 bg-gray-800/30 rounded-lg flex flex-col items-center">
            <UserCheck size={24} className="text-qbr-accent-teal mb-2" />
            <p className="text-sm text-qbr-text-secondary">Candidates Actioned</p>
            <p className="text-xl font-bold">{stats.candidatesActioned}</p>
          </div>
          
          <div className="p-3 bg-gray-800/30 rounded-lg flex flex-col items-center">
            <Activity size={24} className="text-qbr-accent-teal mb-2" />
            <p className="text-sm text-qbr-text-secondary">Users Active</p>
            <p className="text-xl font-bold">{stats.usersActive}</p>
          </div>
        </div>
      </div>
      
      <div className="dashboard-card">
        <h3 className="subsection-title mb-4">Monthly Adoption Trends</h3>
        <div className="h-80">
          <ChartContainer config={{}} className="h-full w-full">
            <LineChart
              data={stats.monthlyData}
              margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" stroke="#333" />
              <XAxis dataKey="month" stroke="#a0a0b9" />
              <YAxis stroke="#a0a0b9" />
              <Tooltip 
                contentStyle={{ backgroundColor: '#1e1c31', borderColor: '#333' }}
                labelStyle={{ color: '#fff' }}
              />
              <Legend />
              <Line 
                type="monotone" 
                dataKey="applicantsIngested" 
                name="Applicants Ingested"
                stroke="#4ce2cb" 
                strokeWidth={2}
                dot={{ r: 4 }}
                activeDot={{ r: 6 }}
              />
              <Line 
                type="monotone" 
                dataKey="candidatesScored" 
                name="Candidates Scored"
                stroke="#7a7cf9" 
                strokeWidth={2}
                dot={{ r: 4 }}
                activeDot={{ r: 6 }}
              />
              <Line 
                type="monotone" 
                dataKey="candidatesViewed" 
                name="Candidates Viewed"
                stroke="#9d71fd" 
                strokeWidth={2}
                dot={{ r: 4 }}
                activeDot={{ r: 6 }}
              />
              <Line 
                type="monotone" 
                dataKey="candidatesActioned" 
                name="Candidates Actioned"
                stroke="#f06292" 
                strokeWidth={2}
                dot={{ r: 4 }}
                activeDot={{ r: 6 }}
              />
            </LineChart>
          </ChartContainer>
        </div>
      </div>
    </section>
  );
};

export default AdoptionStats;
