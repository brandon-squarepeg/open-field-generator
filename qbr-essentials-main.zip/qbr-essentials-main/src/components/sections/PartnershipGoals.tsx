
import React from 'react';
import { Target } from 'lucide-react';

interface Goal {
  priority: number;
  kpi: string;
  description: string;
  targetValue: number | string;
  currentValue: number | string;
  progress: number;
}

interface PartnershipGoalsProps {
  goals: Goal[];
}

const PartnershipGoals: React.FC<PartnershipGoalsProps> = ({ goals }) => {
  return (
    <section id="partnership-goals" className="p-6">
      <h2 className="section-title">Partnership Goals & Success Metrics</h2>
      
      <div className="space-y-6">
        {goals.map((goal, index) => (
          <div key={index} className="dashboard-card">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-8 h-8 rounded-full bg-qbr-accent-purple/20 flex items-center justify-center">
                <Target size={16} className="text-qbr-accent-purple" />
              </div>
              <div>
                <h3 className="font-medium">Priority / KPI Goal {goal.priority}</h3>
                <p className="text-sm text-qbr-text-secondary">{goal.kpi}</p>
              </div>
            </div>
            
            <p className="my-2">{goal.description}</p>
            
            <div className="flex justify-between mb-2">
              <span className="text-sm">Progress</span>
              <span className="text-sm font-medium">{goal.progress}%</span>
            </div>
            
            <div className="progress-bar">
              <div 
                className="progress-value" 
                style={{ width: `${goal.progress}%` }}
              ></div>
            </div>
            
            <div className="flex justify-between mt-4">
              <div>
                <p className="text-sm text-qbr-text-secondary">Current</p>
                <p className="font-medium">{goal.currentValue}</p>
              </div>
              <div className="text-right">
                <p className="text-sm text-qbr-text-secondary">Target</p>
                <p className="font-medium">{goal.targetValue}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

export default PartnershipGoals;
