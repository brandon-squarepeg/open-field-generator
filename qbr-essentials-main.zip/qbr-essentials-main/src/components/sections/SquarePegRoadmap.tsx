
import React from 'react';
import { Milestone, Clock, CheckCircle2 } from 'lucide-react';

interface RoadmapItem {
  id: number;
  feature: string;
  timeframe: string;
  status: string;
  description?: string;
}

interface SquarePegRoadmapProps {
  roadmapItems: RoadmapItem[];
}

const SquarePegRoadmap: React.FC<SquarePegRoadmapProps> = ({ roadmapItems }) => {
  const getStatusIcon = (status: string) => {
    if (status.toLowerCase().includes('completed')) {
      return <CheckCircle2 size={16} className="text-green-500" />;
    } else if (status.toLowerCase().includes('in progress')) {
      return <Clock size={16} className="text-yellow-500" />;
    } else {
      return <Milestone size={16} className="text-qbr-accent-teal" />;
    }
  };

  const getStatusClass = (status: string) => {
    if (status.toLowerCase().includes('completed')) {
      return 'bg-green-500/20 text-green-500';
    } else if (status.toLowerCase().includes('in progress')) {
      return 'bg-yellow-500/20 text-yellow-500';
    } else {
      return 'bg-qbr-accent-teal/20 text-qbr-accent-teal';
    }
  };

  return (
    <section id="squarepeg-roadmap" className="p-6">
      <h2 className="section-title">SquarePeg Roadmap</h2>
      
      <div className="dashboard-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-800">
                <th className="text-left py-3 px-4">#</th>
                <th className="text-left py-3 px-4">Feature</th>
                <th className="text-left py-3 px-4">Timeframe</th>
                <th className="text-left py-3 px-4">Status</th>
                <th className="text-left py-3 px-4">Description</th>
              </tr>
            </thead>
            <tbody>
              {roadmapItems.map((item) => (
                <tr key={item.id} className="border-b border-gray-800/50 hover:bg-gray-800/20">
                  <td className="py-3 px-4">{item.id}</td>
                  <td className="py-3 px-4 font-medium">{item.feature}</td>
                  <td className="py-3 px-4">{item.timeframe}</td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-2">
                      {getStatusIcon(item.status)}
                      <span className={`text-sm px-2 py-1 rounded ${getStatusClass(item.status)}`}>
                        {item.status}
                      </span>
                    </div>
                  </td>
                  <td className="py-3 px-4 text-qbr-text-secondary">{item.description || '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
};

export default SquarePegRoadmap;
