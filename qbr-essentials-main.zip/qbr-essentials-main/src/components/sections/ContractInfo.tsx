
import React from 'react';
import { Calendar, Clock } from 'lucide-react';

interface ContractInfoProps {
  startDate: string;
  onboardingDate: string;
  nextCheckIn: string;
}

const ContractInfo: React.FC<ContractInfoProps> = ({ 
  startDate, 
  onboardingDate, 
  nextCheckIn 
}) => {
  return (
    <section id="contract-info" className="p-6">
      <h2 className="section-title">Contract Information</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="dashboard-card">
          <h3 className="subsection-title flex items-center gap-2">
            <Calendar size={18} />
            Contract Start Date
          </h3>
          <p className="text-lg font-medium">{startDate}</p>
        </div>
        
        <div className="dashboard-card">
          <h3 className="subsection-title flex items-center gap-2">
            <Calendar size={18} />
            Onboarding Date
          </h3>
          <p className="text-lg font-medium">{onboardingDate}</p>
        </div>
        
        <div className="dashboard-card">
          <h3 className="subsection-title flex items-center gap-2">
            <Clock size={18} />
            Next Check-in
          </h3>
          <p className="text-lg font-medium">{nextCheckIn}</p>
        </div>
      </div>
    </section>
  );
};

export default ContractInfo;
