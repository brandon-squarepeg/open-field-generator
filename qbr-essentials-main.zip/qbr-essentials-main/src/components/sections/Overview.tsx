
import React from 'react';
import { Users, TrendingUp, Clock, CheckCircle } from 'lucide-react';

interface OverviewProps {
  clientName: string;
  metrics: {
    activeUsers: number;
    totalCandidates: number;
    avgTimeToHire: string;
    completedFeatures: number;
  };
}

const Overview: React.FC<OverviewProps> = ({ clientName, metrics }) => {
  return (
    <section id="overview" className="p-6">
      <h2 className="section-title">Partnership Overview</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <div className="dashboard-card">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-full bg-qbr-accent-blue/20 flex items-center justify-center">
              <Users size={20} className="text-qbr-accent-blue" />
            </div>
            <p className="text-qbr-text-secondary">Active Users</p>
          </div>
          <p className="text-3xl font-bold text-center">{metrics.activeUsers}</p>
        </div>
        
        <div className="dashboard-card">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-full bg-qbr-accent-teal/20 flex items-center justify-center">
              <TrendingUp size={20} className="text-qbr-accent-teal" />
            </div>
            <p className="text-qbr-text-secondary">Total Candidates</p>
          </div>
          <p className="text-3xl font-bold text-center">{metrics.totalCandidates}</p>
        </div>
        
        <div className="dashboard-card">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-full bg-qbr-accent-purple/20 flex items-center justify-center">
              <Clock size={20} className="text-qbr-accent-purple" />
            </div>
            <p className="text-qbr-text-secondary">Avg Time to Hire</p>
          </div>
          <p className="text-3xl font-bold text-center">{metrics.avgTimeToHire}</p>
        </div>
        
        <div className="dashboard-card">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-full bg-qbr-accent-blue/20 flex items-center justify-center">
              <CheckCircle size={20} className="text-qbr-accent-blue" />
            </div>
            <p className="text-qbr-text-secondary">Completed Features</p>
          </div>
          <p className="text-3xl font-bold text-center">{metrics.completedFeatures}</p>
        </div>
      </div>
      
      <h3 className="subsection-title mb-4">Partnership Highlights</h3>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="dashboard-card bg-gray-800/30 p-5">
          <h4 className="font-medium mb-2 text-qbr-accent-teal">Successful Onboarding</h4>
          <p className="text-qbr-text-secondary">
            Your team has successfully completed the onboarding process and is actively using SquarePeg.
          </p>
        </div>
        
        <div className="dashboard-card bg-gray-800/30 p-5">
          <h4 className="font-medium mb-2 text-qbr-accent-teal">Increased Efficiency</h4>
          <p className="text-qbr-text-secondary">
            Through our partnership, we've seen significant improvements in time-to-hire and recruitment efficiency.
          </p>
        </div>
        
        <div className="dashboard-card bg-gray-800/30 p-5">
          <h4 className="font-medium mb-2 text-qbr-accent-teal">Upcoming Features</h4>
          <p className="text-qbr-text-secondary">
            We're excited to share our roadmap for the next quarter, which includes several features requested by your team.
          </p>
        </div>
      </div>
    </section>
  );
};

export default Overview;
