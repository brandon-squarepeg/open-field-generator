
import React from 'react';
import { CheckCircle2, Clock, AlertCircle } from 'lucide-react';

interface FeatureRequest {
  id: number;
  feature: string;
  status: string;
  notes?: string;
}

interface FeatureRequestsProps {
  requests: FeatureRequest[];
}

const FeatureRequests: React.FC<FeatureRequestsProps> = ({ requests }) => {
  const getStatusIcon = (status: string) => {
    if (status.toLowerCase().includes('delivered')) {
      return <CheckCircle2 size={16} className="text-green-500" />;
    } else if (status.toLowerCase().includes('in-progress')) {
      return <Clock size={16} className="text-yellow-500" />;
    } else {
      return <AlertCircle size={16} className="text-blue-500" />;
    }
  };

  const getStatusClass = (status: string) => {
    if (status.toLowerCase().includes('delivered')) {
      return 'bg-green-500/20 text-green-500';
    } else if (status.toLowerCase().includes('in-progress')) {
      return 'bg-yellow-500/20 text-yellow-500';
    } else {
      return 'bg-blue-500/20 text-blue-500';
    }
  };

  return (
    <section id="feature-requests" className="p-6">
      <h2 className="section-title">Feature Requests</h2>
      
      <div className="dashboard-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-800">
                <th className="text-left py-3 px-4">#</th>
                <th className="text-left py-3 px-4">Feature Request</th>
                <th className="text-left py-3 px-4">Status</th>
                <th className="text-left py-3 px-4">Notes</th>
              </tr>
            </thead>
            <tbody>
              {requests.map((request) => (
                <tr key={request.id} className="border-b border-gray-800/50 hover:bg-gray-800/20">
                  <td className="py-3 px-4">{request.id}</td>
                  <td className="py-3 px-4">{request.feature}</td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-2">
                      {getStatusIcon(request.status)}
                      <span className={`text-sm px-2 py-1 rounded ${getStatusClass(request.status)}`}>
                        {request.status}
                      </span>
                    </div>
                  </td>
                  <td className="py-3 px-4 text-qbr-text-secondary">{request.notes || '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
};

export default FeatureRequests;
