
import React from 'react';
import { User, Calendar, MessageSquare } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface Stakeholder {
  title: string;
  name: string;
  email: string;
}

interface ContactInfoProps {
  clientName: string;
  stakeholdersClient: Stakeholder[];
  stakeholdersSquarePeg: Stakeholder[];
  calendarLink: string;
  slackChannel: string;
}

const ContactInfo: React.FC<ContactInfoProps> = ({ 
  clientName,
  stakeholdersClient, 
  stakeholdersSquarePeg,
  calendarLink, 
  slackChannel 
}) => {
  return (
    <section id="contact-info" className="p-6">
      <h2 className="section-title">Contact Information</h2>
      
      <div className="grid grid-cols-1 gap-6">
        <div className="dashboard-card">
          <h3 className="subsection-title flex items-center gap-2 mb-4">
            <User size={18} />
            Key Stakeholders - {clientName}
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {stakeholdersClient.map((stakeholder, index) => (
              <div key={index} className="p-3 bg-gray-800/50 rounded-lg">
                <p className="text-qbr-text-secondary text-sm">{stakeholder.title}</p>
                <p className="font-medium">{stakeholder.name}</p>
                <p className="text-sm text-qbr-accent-teal">{stakeholder.email}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="dashboard-card">
          <h3 className="subsection-title flex items-center gap-2 mb-4">
            <User size={18} />
            Key Stakeholders - SquarePeg
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {stakeholdersSquarePeg.map((stakeholder, index) => (
              <div key={index} className="p-3 bg-gray-800/50 rounded-lg">
                <p className="text-qbr-text-secondary text-sm">{stakeholder.title}</p>
                <p className="font-medium">{stakeholder.name}</p>
                <p className="text-sm text-qbr-accent-teal">{stakeholder.email}</p>
              </div>
            ))}
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="dashboard-card">
            <h3 className="subsection-title flex items-center gap-2 mb-4">
              <Calendar size={18} />
              Calendar Link
            </h3>
            <Button 
              className="bg-qbr-accent-blue hover:bg-qbr-accent-blue/80"
              onClick={() => window.open(calendarLink, '_blank')}
            >
              Book a Call with SquarePeg
            </Button>
          </div>
          
          <div className="dashboard-card">
            <h3 className="subsection-title flex items-center gap-2 mb-4">
              <MessageSquare size={18} />
              Slack Channel
            </h3>
            <Button 
              className="bg-qbr-accent-purple hover:bg-qbr-accent-purple/80"
              onClick={() => window.open(slackChannel, '_blank')}
            >
              View Shared Slack Channel
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactInfo;
