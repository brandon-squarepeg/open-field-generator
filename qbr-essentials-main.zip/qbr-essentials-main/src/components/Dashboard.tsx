
import React from 'react';
import Header from './layout/Header';
import Sidebar from './layout/Sidebar';
import Overview from './sections/Overview';
import PartnershipTimeline from './sections/PartnershipTimeline';
import ContactInfo from './sections/ContactInfo';
import PartnershipGoals from './sections/PartnershipGoals';
import AdoptionStats from './sections/AdoptionStats';
import ROIStats from './sections/ROIStats';
import FeatureRequests from './sections/FeatureRequests';
import SquarePegRoadmap from './sections/SquarePegRoadmap';
import Announcements from './sections/Announcements';

// Sample data for demonstration
const sampleData = {
  clientInfo: {
    name: 'Acme Corporation',
    logo: '/acmelogo.png'
  },
  overviewMetrics: {
    activeUsers: 32,
    totalCandidates: 847,
    avgTimeToHire: '18 days',
    completedFeatures: 7
  },
  contractInfo: {
    startDate: 'January 15, 2023',
    onboardingDate: 'February 1, 2023',
    nextCheckIn: 'July 15, 2023'
  },
  stakeholdersClient: [
    { title: 'HR Director', name: 'Jane Smith', email: 'jane.smith@acme.com' },
    { title: 'Talent Acquisition', name: 'John Doe', email: 'john.doe@acme.com' },
    { title: 'VP of People', name: 'Alice Johnson', email: 'alice.johnson@acme.com' }
  ],
  stakeholdersSquarePeg: [
    { title: 'Account Management', name: 'Kahina', email: 'kahina@squarepeghires.com' },
    { title: 'Sales', name: 'Brittany', email: 'brittany@squarepeghires.com' },
    { title: 'Product Manager', name: 'Chris', email: 'chris@squarepeghires.com' }
  ],
  contactInfo: {
    calendarLink: 'https://calendly.com/squarepeg-team',
    slackChannel: 'https://acme-squarepeg.slack.com'
  },
  partnershipGoals: [
    {
      priority: 1,
      kpi: 'Reduce Time to Hire',
      description: 'Decrease average time-to-hire by 25% over the next quarter',
      targetValue: '15 days',
      currentValue: '18 days',
      progress: 76
    },
    {
      priority: 2,
      kpi: 'Increase Quality of Hire',
      description: 'Improve the average quality of hire score from 7.5 to 9',
      targetValue: '9/10',
      currentValue: '7.8/10',
      progress: 43
    },
    {
      priority: 3,
      kpi: 'Expand User Adoption',
      description: 'Increase active users from 25 to 50 across all departments',
      targetValue: '50 users',
      currentValue: '32 users',
      progress: 64
    }
  ],
  adoptionStats: {
    applicantsIngested: 1240,
    candidatesScored: 987,
    jobRequirementsSaved: 45,
    candidatesViewed: 764,
    candidatesActioned: 562,
    usersActive: 32,
    avgTimeInStage: '4.3 days',
    monthlyData: [
      { month: 'Jan', applicantsIngested: 200, candidatesScored: 160, candidatesViewed: 140, candidatesActioned: 100 },
      { month: 'Feb', applicantsIngested: 220, candidatesScored: 180, candidatesViewed: 150, candidatesActioned: 110 },
      { month: 'Mar', applicantsIngested: 240, candidatesScored: 190, candidatesViewed: 160, candidatesActioned: 120 },
      { month: 'Apr', applicantsIngested: 260, candidatesScored: 210, candidatesViewed: 170, candidatesActioned: 130 },
      { month: 'May', applicantsIngested: 280, candidatesScored: 230, candidatesViewed: 180, candidatesActioned: 140 },
      { month: 'Jun', applicantsIngested: 300, candidatesScored: 250, candidatesViewed: 190, candidatesActioned: 150 }
    ]
  },
  roiStats: {
    hoursSaved: 246,
    hoursSavedLastPeriod: 210,
    moneySaved: 78500,
    moneySavedLastPeriod: 65000,
    timeToFill: '18 days',
    timeToFillLastPeriod: '22 days',
    qualityScore: 78,
    qualityScoreLastPeriod: 72
  },
  featureRequests: [
    { id: 1, feature: 'Pin jobs to top', status: 'Not started - Q2 delivery' },
    { id: 2, feature: 'Add boolean logic', status: 'In-progress' },
    { id: 3, feature: 'Show score distribution', status: 'Delivered March 15th' }
  ],
  roadmapItems: [
    { 
      id: 1, 
      feature: 'Advanced Candidate Filtering', 
      timeframe: 'Q3 2023', 
      status: 'Planned',
      description: 'Enhance filtering capabilities with saved searches and boolean logic' 
    },
    { 
      id: 2, 
      feature: 'API Integrations', 
      timeframe: 'Q2 2023', 
      status: 'In Progress',
      description: 'Connect with popular ATS systems' 
    },
    { 
      id: 3, 
      feature: 'Mobile App', 
      timeframe: 'Q4 2023', 
      status: 'Planned',
      description: 'Native mobile experience for on-the-go recruitment' 
    },
    { 
      id: 4, 
      feature: 'Enhanced Analytics', 
      timeframe: 'Q2 2023', 
      status: 'Completed',
      description: 'Improved dashboard with exportable reports' 
    }
  ],
  announcements: [
    {
      id: 1,
      title: 'New Feature Release: Score Distribution',
      date: 'March 15, 2023',
      description: "We've launched our new score distribution feature, allowing you to visualize candidate scoring patterns.",
      isNew: true
    },
    {
      id: 2,
      title: 'Platform Update v2.4',
      date: 'April 5, 2023',
      description: 'Our latest platform update includes performance improvements and bug fixes.',
      isNew: false
    },
    {
      id: 3,
      title: 'Upcoming Maintenance',
      date: 'May 10, 2023',
      description: 'Scheduled maintenance on May 15th from 2-4am EST. The platform may experience brief downtime.',
      isNew: true
    },
    {
      id: 4,
      title: 'New Integration: Workday',
      date: 'June 1, 2023',
      description: "We're excited to announce our new integration with Workday, making it easier to sync candidate data.",
      isNew: false
    }
  ]
};

const Dashboard: React.FC = () => {
  return (
    <div className="flex min-h-screen bg-gradient-dark text-white">
      <Sidebar />
      
      <div className="flex-1 flex flex-col">
        <Header 
          companyName={sampleData.clientInfo.name} 
          companyLogo={sampleData.clientInfo.logo} 
        />
        
        <div className="flex-1 overflow-auto">
          <Overview 
            clientName={sampleData.clientInfo.name} 
            metrics={sampleData.overviewMetrics} 
          />
          
          <PartnershipTimeline 
            startDate={sampleData.contractInfo.startDate}
            onboardingDate={sampleData.contractInfo.onboardingDate}
            nextCheckIn={sampleData.contractInfo.nextCheckIn}
          />
          
          <ContactInfo 
            clientName={sampleData.clientInfo.name}
            stakeholdersClient={sampleData.stakeholdersClient}
            stakeholdersSquarePeg={sampleData.stakeholdersSquarePeg}
            calendarLink={sampleData.contactInfo.calendarLink}
            slackChannel={sampleData.contactInfo.slackChannel}
          />
          
          <PartnershipGoals goals={sampleData.partnershipGoals} />
          
          <AdoptionStats stats={sampleData.adoptionStats} />
          
          <ROIStats stats={sampleData.roiStats} />
          
          <FeatureRequests requests={sampleData.featureRequests} />
          
          <SquarePegRoadmap roadmapItems={sampleData.roadmapItems} />
          
          <Announcements announcements={sampleData.announcements} />
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
